import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Введите размерность матрицы: ");
        int a = sc.nextInt();
        Matrix matrix = new Matrix(a);
        System.out.println(matrix);
        System.out.println("Сумма: " + matrix.summ());
        System.out.println("Произведение: " + matrix.multiply());
        System.out.println("Вычитание: " + matrix.substrct());
    }
}