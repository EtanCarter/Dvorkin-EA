import java.util.Arrays;

import java.util.Random;

public class Matrix {
    private int[][] matrix;

    Matrix(int size) {
        matrix = new int[size][size];
        Random rand = new Random();

        for (var i = 0; i < matrix.length; i++) {
            for (var j = 0; j < matrix[i].length; j++) {
                matrix[i][j] = rand.nextInt(10);
            }
        }
    }

    public int summ() {
        int summ = 0;
        for (var i = 0; i < matrix.length; i++) {
            for (var j = 0; j < matrix[i].length; j++) {
                if (i < j) {
                    summ += matrix[i][j];
                }

            }
        }
        return summ;
    }

    public int multiply() {
        int multiplication = 1;
        for (var i = 0; i < matrix.length; i++) {
            for (var j = 0; j < matrix[i].length; j++) {
                if (i == j) {
                    multiplication *= matrix[i][j];
                }
            }

        }
        return multiplication;
    }

    public int substrct() {
        int subtraction = 0;
        for (var i = 0; i < matrix.length; i++) {
            for (var j = 0; j < matrix[i].length; j++) {
                if (i > j) {
                    subtraction -= matrix[i][j];
                }
            }
        }
        return subtraction;
    }


    @Override
    public String toString() {
        return Arrays.deepToString(matrix);
    }

}
